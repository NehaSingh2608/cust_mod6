package com.cap.CustomerProfile.service;

import com.cap.CustomerProfile.bean.CustomerProfile;
import com.cap.CustomerProfile.exception.CustomerdoesnotExist;

public interface ICustomerProfileChangeSercvice  {

	CustomerProfile changeProfile(CustomerProfile customer) throws CustomerdoesnotExist;
}
