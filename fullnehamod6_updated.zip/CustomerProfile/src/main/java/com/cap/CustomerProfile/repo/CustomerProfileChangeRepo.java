package com.cap.CustomerProfile.repo;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cap.CustomerProfile.bean.CustomerProfile;
import com.cap.CustomerProfile.exception.CustomerdoesnotExist;

@Transactional
@Repository
public class CustomerProfileChangeRepo implements ICustomerProfileChangeRepo{

	@PersistenceContext
	EntityManager entity;
	
	@Override
	public CustomerProfile changeProfile(CustomerProfile customer) throws CustomerdoesnotExist {
		CustomerProfile profile=entity.find(CustomerProfile.class,customer.getMobile_no());
		profile.setAddress(customer.getAddress());
		profile.setPassword(customer.getPassword());
		System.out.println(customer);
		entity.merge(customer);
		entity.flush();
		return customer;
			
	}
}
