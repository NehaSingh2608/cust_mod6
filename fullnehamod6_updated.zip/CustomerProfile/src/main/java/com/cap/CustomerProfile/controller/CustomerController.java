package com.cap.CustomerProfile.controller;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.cap.CustomerProfile.bean.CustomerProfile;
import com.cap.CustomerProfile.exception.CustomerdoesnotExist;
import com.cap.CustomerProfile.service.ICustomerProfileChangeSercvice;

@Controller
public class CustomerController {

	@Autowired
	ICustomerProfileChangeSercvice service;

	
	@RequestMapping("/")
	public String hello() {
		return "/pages/customer.jsp";
	}
	

	@RequestMapping(value="/profile")
	public String changeProfile(){
		
		return "/pages/profile.jsp";
	}
	
	
	@RequestMapping("/change")
	public String change(CustomerProfile customer) throws CustomerdoesnotExist {
		service.changeProfile(customer);
		System.out.println(customer.getMobile_no()+"mobile"+customer.getAddress()+"address"+customer.getPassword()+"password");
		return "/pages/sucess.jsp";
	}
	
}
