package com.cap.CustomerProfile.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cap.CustomerProfile.bean.CustomerProfile;
import com.cap.CustomerProfile.exception.CustomerdoesnotExist;
import com.cap.CustomerProfile.repo.ICustomerProfileChangeRepo;



@Service
@Transactional
public class CustomerProfileChangeService implements ICustomerProfileChangeSercvice{

	@Autowired
	private ICustomerProfileChangeRepo repo;

	@Override
	public CustomerProfile changeProfile(CustomerProfile customer) throws CustomerdoesnotExist {
		if(customer.getMobile_no()==null)
			throw new CustomerdoesnotExist("||||||||||||***********||||||||||||");
		
		return repo.changeProfile(customer);
	}

	
	}


