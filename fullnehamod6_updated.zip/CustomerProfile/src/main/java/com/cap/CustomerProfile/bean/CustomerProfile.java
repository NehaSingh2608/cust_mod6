package com.cap.CustomerProfile.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Customer")
public class CustomerProfile {
	@Id
	private String mobile_no;
	
	private String password;
	
	private String address;
	
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public CustomerProfile(String mobile_no, String password, String address) {
		super();
		this.mobile_no = mobile_no;
		this.password = password;
		this.address = address;
	}
	public CustomerProfile() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
