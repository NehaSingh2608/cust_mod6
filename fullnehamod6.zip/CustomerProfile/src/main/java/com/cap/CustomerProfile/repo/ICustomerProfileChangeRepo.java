package com.cap.CustomerProfile.repo;

import com.cap.CustomerProfile.bean.CustomerProfile;
import com.cap.CustomerProfile.exception.CustomerdoesnotExist;

public interface ICustomerProfileChangeRepo {
	
	CustomerProfile changeProfile(CustomerProfile customer, String mobile_no) throws CustomerdoesnotExist;

	}
