package com.cap.CustomerProfile.controller;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.cap.CustomerProfile.bean.CustomerProfile;
import com.cap.CustomerProfile.exception.CustomerdoesnotExist;
import com.cap.CustomerProfile.service.ICustomerProfileChangeSercvice;

@Controller
public class CustomerController {

	@Autowired
	ICustomerProfileChangeSercvice service;

	
	@RequestMapping("/")
	public String hello() {
		return "/pages/customer.jsp";
	}
	

	@RequestMapping( value ="/changeProfile{mobile_no}",consumes="application/Json",produces="application/json")
	public String changeProfile(@RequestBody CustomerProfile customer) throws CustomerdoesnotExist  {
		 //service.changeProfile(mobileNo, password, address);
	//	service.changeProfile(customer, null);
		 return "/pages/profile.jsp";
	}
	
	@RequestMapping(method=RequestMethod.POST, value ="/changeProfile{mobile_no}",consumes="application/Json",produces="application/json")
	public void registerCustomer(@RequestBody CustomerProfile customer) {
		
		System.out.println(json);
		
		try {
			JSONObject jSon = new JSONObject(json);
			RestTemplate restTemplate = new RestTemplate();
			service.changeProfile(customer, null);
			restTemplate.postForObject("http://localhost:4496/customerRegister", jSon, JSONObject.class);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
}
