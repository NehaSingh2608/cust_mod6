package com.cap.CustomerProfile.repo;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cap.CustomerProfile.bean.CustomerProfile;
import com.cap.CustomerProfile.exception.CustomerdoesnotExist;

@Transactional
@Repository
public class CustomerProfileChangeRepo implements ICustomerProfileChangeRepo{

	@PersistenceContext
	EntityManager entity;
	
	@Override
	public CustomerProfile changeProfile(CustomerProfile customer,String mobile_no) throws CustomerdoesnotExist {
		customer=entity.find(CustomerProfile.class, mobile_no);
		if(customer == null)
			throw new CustomerdoesnotExist("Customer does not exsit");
		entity.merge(customer);
		entity.flush();
		return customer;
			
	}
}
